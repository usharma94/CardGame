﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UpmaCardGame
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        Random rand = new Random();
        CardImage[] c = new CardImage[3];
        int[] cardID = new int[3];
        int ShuffleCount = 0;
        int cardUserID = 0;
        int cardAIID = 0;
        int userScore = 0;
        int AIScore = 0;
        int userTotalScore = 0;
        int AITotalScore = 0;

        public MainPage()
        {
            this.InitializeComponent();

            SetupGame();
        }

        private void SetupGame()
        {
            c[0] = Card1;
            c[1] = Card2;
            c[2] = Card3;

            HideOrDisplay(Visibility.Collapsed);
            ButtonPanel.Visibility = Visibility.Collapsed;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartButton.Visibility = Visibility.Collapsed;
            HideOrDisplay(Visibility.Visible);

            ShuffleCard();

            setCardBack(CardUser);
            setCardBack(CardAI);
        }

        private void HideOrDisplay(Visibility vis)
        {           
            CardPanel.Visibility = vis;
            CardUser.Visibility = vis;
            CardAI.Visibility = vis;
            ShuffleButton.Visibility = vis;
            YourCard.Visibility = vis;
            CPUCard.Visibility = vis;
            TurnScoreCPU.Visibility = vis;
            TurnScoreUser.Visibility = vis;
            UserScore.Visibility = vis;
            CPUScore.Visibility = vis;
        }

        private void ShuffleButton_Click(object sender, RoutedEventArgs e)
        {
            ShuffleCount += 1;

            ShuffleCard();

            if (ShuffleCount == 2)
            {
                ShuffleButton.Visibility = Visibility.Collapsed;
                return;
            }
        }

        public void ShuffleCard()
        {
            for (int i = 0; i < 3; i++)
            {
                while (true)
                {
                    int rnd = rand.Next(0, 13);
                    if (c[i].DisplayFace(rnd))
                    {
                        cardID[i] = rnd;
                        c[i].DisplayFace(rnd);
                        break;
                    }
                }
            }
        }

        private void AISelectCard()
        {
            while (true)
            {
                int rnd = rand.Next(0, 13);
                if (CardAI.DisplayFace(rnd))
                {
                    CardAI.DisplayFace(rnd);
                    CardAI.RemoveCard(rnd);
                    cardAIID = rnd;
                    break;
                }
            }
        }

        private void setCardBack(CardImage c)
        {
            c.DisplayFace(13);
        }

        private void DisableCardButtons(bool setCard)
        {
            card1Button.IsEnabled = setCard;
            card2Button.IsEnabled = setCard;
            card3Button.IsEnabled = setCard;
        }

        private void card1Button_Click(object sender, RoutedEventArgs e)
        {
            Card1.RemoveCard(cardID[0]);
            CardUser.DisplayFace(cardID[0]);
            cardUserID = cardID[0];
            ShuffleButton.Visibility = Visibility.Collapsed;
            GameLogic();
        }

        private void card2Button_Click(object sender, RoutedEventArgs e)
        {
            Card2.RemoveCard(cardID[1]);
            CardUser.DisplayFace(cardID[1]);
            cardUserID = cardID[1];
            ShuffleButton.Visibility = Visibility.Collapsed;
            GameLogic();
        }

        private void card3Button_Click(object sender, RoutedEventArgs e)
        {
            Card3.RemoveCard(cardID[2]);
            CardUser.DisplayFace(cardID[2]);
            cardUserID = cardID[2];
            ShuffleButton.Visibility = Visibility.Collapsed;
            GameLogic();
        }

        private void GameLogic()
        {
            DisableCardButtons(false);
            setCardBack(Card1);
            setCardBack(Card2);
            setCardBack(Card3);
            
            AISelectCard();

            userScore = CardUser.GetCardScore(cardUserID) * 10;
            AIScore = CardAI.GetCardScore(cardAIID) * 10;

            userTotalScore += userScore;
            AITotalScore += AIScore;

            if (userScore > AIScore)
            {
                GameMessage.Text = "User won with score of " + userScore;
            }
            else if (AIScore > userScore)
            {
                GameMessage.Text = "AI won with score of " + AIScore;
            }
            else
            {
                GameMessage.Text = "It was a tie!";
            }

            TurnScoreUser.Text = "Turn Score: " + userScore;
            TurnScoreCPU.Text = "Turn Score: " + AIScore;
            UserScore.Text = "Main Score: " + userTotalScore;
            CPUScore.Text = "Main Score: " + AITotalScore;

            ButtonPanel.Visibility = Visibility.Visible;
        }

        private void NextRound_Click(object sender, RoutedEventArgs e)
        {
            ShuffleCard();
            ShuffleCount = 0;
            setCardBack(CardUser);
            setCardBack(CardAI);
            ShuffleButton.Visibility = Visibility.Visible;
            ButtonPanel.Visibility = Visibility.Collapsed;
            DisableCardButtons(true);
            GameMessage.Text = "";
        }

        private void EndGame_Click(object sender, RoutedEventArgs e)
        {
            ShuffleCount = 0;
            userScore = 0;
            AIScore = 0;
            userTotalScore = 0;
            AITotalScore = 0;

            TurnScoreUser.Text = "Turn Score: ";
            TurnScoreCPU.Text = "Turn Score: ";
            UserScore.Text = "Main Score: ";
            CPUScore.Text = "Main Score: ";

            StartButton.Visibility = Visibility.Visible;
            HideOrDisplay(Visibility.Collapsed);
            GameMessage.Text = "";
            ButtonPanel.Visibility = Visibility.Collapsed;
            DisableCardButtons(true);
        }
    }
}
