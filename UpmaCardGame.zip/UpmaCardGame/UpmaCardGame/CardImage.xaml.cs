﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace UpmaCardGame
{
    public struct Card
    {
        public Image face { get; set; }
        public int amount { get; set; }
        public int score { get; set; }

        public void decrement()
        {
            amount = amount - 1;
        }
    }

    public sealed partial class CardImage : UserControl
    {
        //dictionary with key = num from above (releated to img) and key with amount of cards of that type
        //{ image number, # in deck}
        //created a Dictionary of list and int
        List<Card> cards = new List<Card>();

        public CardImage()
        {
            this.InitializeComponent();
            CreateDeck();
            //DisplayFace(7);
        }

        private Card createCard(Image i, int amt, int sc)
        {
            Card c = new Card();
            c.face = i;
            c.amount = amt;
            c.score = sc;

            return c;
        }

        private void CreateDeck()
        {
            int amt = 4;
            cards.Add(createCard(Card1, amt, 30)); //Ace
            cards.Add(createCard(Card2, amt, 2)); //2
            cards.Add(createCard(Card3, amt, 3)); //3
            cards.Add(createCard(Card4, amt, 4)); //4
            cards.Add(createCard(Card5, amt, 5)); //5 
            cards.Add(createCard(Card6, amt, 6)); //6
            cards.Add(createCard(Card7, amt, 7)); //7
            cards.Add(createCard(Card8, amt, 8)); //8
            cards.Add(createCard(Card9, amt, 9)); //9
            cards.Add(createCard(Card10, amt, 10));//10
            cards.Add(createCard(Card11, amt, 15));//Jack
            cards.Add(createCard(Card12, amt, 20));//Queen
            cards.Add(createCard(Card13, amt, 25));//King
            cards.Add(createCard(CardBack, amt, 0));//back
        }

        //min 0 max 13
        public bool DisplayFace(int FaceID)
        {
            bool show = false;
            for (int i = 0; i < cards.Count; i++)
            {
                if (i == FaceID)
                {
                    if (cards[i].amount > 0)
                    {
                        cards[i].face.Visibility = Visibility.Visible;
                        show = true;
                    }
                    else
                    {
                        show = false;
                    }
                }
                else
                {
                    cards[i].face.Visibility = Visibility.Collapsed;
                }
            }

            if (show)
            {
                return true;
            }
            return false;
        }

        public void RemoveCard(int ID)
        {
            cards[ID] = createCard(cards[ID].face, cards[ID].amount - 1, cards[ID].score);
        }

        public int GetCardScore(int ID)
        {
            return cards[ID].score;
        }
    }
}
