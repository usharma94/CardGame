﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UpmaCardGameSimple
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    /// \
    public sealed partial class MainPage : Page
    {
        public int[] Card = new int[3];
        public int Score = 0;
        public int ShuffleCount = 0;

        public Random RandomGenerator = new Random();

        public MainPage()
        {
            this.InitializeComponent();
            SetupGame();
        }

        public void RandomCards()
        {
            for (int i = 0; i < Card.Length; i++)
            {
                int CardValue = RandomGenerator.Next(1, 13);
                Card[i] = CardValue;
            }

            Card1.DisplayFace(Card[0]);
            Card2.DisplayFace(Card[1]);
            Card3.DisplayFace(Card[2]);
        }

        private void ShuffleButton_Click(object sender, RoutedEventArgs e)
        {
         
            RandomCards();
            ShuffleCount += 1;
            if (ShuffleCount == 2)
            {
                ShuffleButton.Visibility = Visibility.Collapsed;
            }
            
        }

        private void SetupGame()
        {
            WinText.Text = "Click the \"Start Game\" button to play";
            ScoreText.Text = $"Score: {Score}";
            Card1.Visibility = Visibility.Collapsed;
            Card2.Visibility = Visibility.Collapsed;
            Card3.Visibility = Visibility.Collapsed;
            CardUser.Visibility = Visibility.Collapsed;
            CardAI.Visibility = Visibility.Collapsed;
            NewGameButton.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Collapsed;
            EndGame.Visibility = Visibility.Collapsed;
            StartButton.Visibility = Visibility.Visible;
        }


        private void ApplyGameRules()
        {
            int NewScore = 0;
            string WinMessage = "";

            /*if (Dice[0] == Dice[1] && Dice[0] == Dice[2])
            {
                // Triple
                if (Dice[0] < 6)
                {
                    NewScore = Dice[0] * 100;
                    WinMessage = $"You rolled a {Dice[0]} for {NewScore} points.";
                }
              

            Score = Score + NewScore;
            ScoreText.Text = $"Score: {Score}";
            WinText.Text = WinMessage;
            */
        }

      
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            Card1.Visibility = Visibility.Visible;
            Card2.Visibility = Visibility.Visible;
            Card3.Visibility = Visibility.Visible;
            CardUser.Visibility = Visibility.Visible;
            CardAI.Visibility = Visibility.Visible;
            NewGameButton.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Visible;
            EndGame.Visibility = Visibility.Collapsed;
            StartButton.Visibility = Visibility.Collapsed;
            RandomCards();
            CardUser.DisplayFace(14);
            CardAI.DisplayFace(14);

            //Enable the game buttons 
            card1Button.IsEnabled = true;
            card2Button.IsEnabled = true;
            card3Button.IsEnabled = true;

        }

        private void EndGame_Click(object sender, RoutedEventArgs e)
        {

        }

        private void NewGameButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void card1Button_Click(object sender, RoutedEventArgs e)
        {
            DisableButtons();
            AISelectCard();
            CardUser.DisplayFace(Card[0]);
        }

        private void card2Button_Click(object sender, RoutedEventArgs e)
        
        {
            DisableButtons();
            AISelectCard();
            CardUser.DisplayFace(Card[1]);
        }

        private void card3Button_Click(object sender, RoutedEventArgs e)
        {
            DisableButtons();
            AISelectCard();
            CardUser.DisplayFace(Card[2]);
        }

        private void Card1_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void AISelectCard()
        {
            int CardValueAI = RandomGenerator.Next(1, 13);
            CardAI.DisplayFace(CardValueAI);
        }

        //disable Card buttons function And Hides Shuffle 
        private void DisableButtons()
        {
            card1Button.IsEnabled = false;
            card2Button.IsEnabled = false;
            card3Button.IsEnabled = false;
            ShuffleButton.Visibility = Visibility.Collapsed;

        }

        private void CardUser_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}

