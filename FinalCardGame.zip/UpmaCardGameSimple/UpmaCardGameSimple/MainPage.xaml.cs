﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UpmaCardGameSimple
{
       /****************************************************************************************
        * Method: Card Game
        * Programmer(s):  Upma Sharma, Duncan Levings, Jayce Merinchuk, Aditya Chattopadhyay
        * Date: August 15, 2018
        * Description: Display the back of cards, enable buttons, for loop to pick new cards,
        * while loop to ensure no two cards picked were the same, output cards to the screen.
        * Input(s)/Output(s): No inputs, removes text message, enables buttons, outputs new
        * cards to the screen. Final Version of Game
        * *************************************************************************************/
    public sealed partial class MainPage : Page
    {
        public int[] Card = new int[3];
        public int Score = 0;
        public int AIScore = 0;
        public int ShuffleCount = 0;

        public Random RandomGenerator = new Random();

        public MainPage()
        {
            this.InitializeComponent();
            SetupGame();
        }
        /****************************************************************************************
        * Method: Random Cards Deck
        * Programmer(s):  Upma Sharma, Duncan Levings
        * Date: August 13, 2018
        * Description: For loop method that randomly generates 3 cards to be displayed from 
        * the deck. 
        * *************************************************************************************/
        public void RandomCards()
        {
            for (int i = 0; i < Card.Length; i++)
            {
                int CardValue = RandomGenerator.Next(1, 13);
                Card[i] = CardValue;
            }

            Card1.DisplayFace(Card[0]);
            Card2.DisplayFace(Card[1]);
            Card3.DisplayFace(Card[2]);
        }
        /****************************************************************************************
        * Method: Shuffle Button
        * Programmer(s):  Upma Sharma
        * Date: August 13, 2018
        * Description: Shuffle button without counter. The shuffle button becomes invisible with
        * if statement. Can shuffle max of two times.
        * *************************************************************************************/
        private void ShuffleButton_Click(object sender, RoutedEventArgs e)
        {
         
            RandomCards();
            ShuffleCount += 1;
            if (ShuffleCount == 2)
            {
                ShuffleButton.Visibility = Visibility.Collapsed;
            }
            
        }
        //Hides all buttons and text except Start Game and Game Rules. 
        private void SetupGame()
        {
            GameRule.Text = "Click the \"Start Game\" button to play";
            //ScoreText.Text = $"Score: {Score}";
            Card1.Visibility = Visibility.Collapsed;
            Card2.Visibility = Visibility.Collapsed;
            Card3.Visibility = Visibility.Collapsed;
            //make card buttons invisible
            card1Button.Visibility = Visibility.Collapsed;
            card2Button.Visibility = Visibility.Collapsed;
            card3Button.Visibility = Visibility.Collapsed;
            //make User and AI card invisible
            CardUser.Visibility = Visibility.Collapsed;
            CardAI.Visibility = Visibility.Collapsed;
            NewGameButton.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Collapsed;
            EndGame.Visibility = Visibility.Collapsed;
            StartButton.Visibility = Visibility.Visible;
            User.Visibility = Visibility.Collapsed;
            AI.Visibility = Visibility.Collapsed;
            Scores.Visibility = Visibility.Collapsed;
            GameRules.Visibility = Visibility.Visible;
        }
        //Method to display back of cards.
        private void BackCards()
        {
            Card1.DisplayFace(14);
            Card2.DisplayFace(14);
            Card3.DisplayFace(14);
           
        }

        /****************************************************************************************
        * Method: ApplyGameRules()
        * Programmer(s): Jayce Merinchuk, Upma Sharma
        * Date: August 09, 2018
        * Description: Initialize variables for use, grab passed variables and assign a score to
        * the card, choose a random card for the opponent, while loop to ensure the card is not
        * the same as the one the user has, assign it to the opponentcard box, if statement to 
        * check who's card has a higher index value. If the user's card is higher, they are assigned
        * a score of the index value multiplied by 100. Set message. Add it to the total score.
        * Input(s)/Output(s): Inputs - PlayerIndex from a PickCard Method based on what button 
        * is pressed. 
        * Outputs - Win or Lose message based on result of if statement.
        * *************************************************************************************/
        private void ApplyGameRules(int PlayerIndex)
        {
            // Initialize the variables for use below.
            int NewScore = 0;
            string WinMessage = "";

            // Grab the Player's card index to ensure the opponent card doesn't choose the same one
            int ChosenCardIndex = PlayerIndex;
            int CardValue = ChosenCardIndex;
            TurnScoreUser.Text = "Card Value = " + CardValue;

            // Choose a random card for the AI player
            int rand = RandomGenerator.Next(1, 14);
            // While loop to ensure the AI doesn't pick the same card the Player did
            while (ChosenCardIndex == rand)
            {
                rand = RandomGenerator.Next(1, 14);
            }
            // Assign the card to the opponent
            CardAI.DisplayFace(rand);
            int OpponentCardIndex = rand;
            int CardVal = OpponentCardIndex;
            TurnScoreAI.Text = "Card Value = " + CardVal;

            /* If statement to check if chosen card value is higher than opponent card.
               If true, compute the score, if false, score = 0 and set message to say sorry and try again. */

            // Compute score
            NewScore = ((ChosenCardIndex + OpponentCardIndex) * 10);
            //Message upon score calculation - Winner of Loser 
            if (ChosenCardIndex > OpponentCardIndex)
            {
                           
                WinMessage = "Awesome! You won! You gained " + NewScore + " points on your score!";
                Score += NewScore;
              
            }
            else
            {
           
                WinMessage = "Sorry, the opponent had the better card this time...";
                AIScore += NewScore;
             
            }     
            //Displays Overall Scores of User and AI
            OverallScoreUser.Text = $"Score: {Score}";
            OverallScoreAI.Text = $"Score: {AIScore}";
            WinText.Text = WinMessage;
            //Makes New Game, End Game, Shuffle Buttons Visible/Collapsed
            NewGameButton.Visibility = Visibility.Visible;
            EndGame.Visibility = Visibility.Visible;
            ShuffleButton.Visibility = Visibility.Collapsed;
        }

        //Button hides Game rules and displays the 3 Random Card, Shuffle buttons.
        //AI and USER cards back faces
       
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            GameRule.Visibility = Visibility.Collapsed;
            Card1.Visibility = Visibility.Visible;
            Card2.Visibility = Visibility.Visible;
            Card3.Visibility = Visibility.Visible;
            card1Button.Visibility = Visibility.Visible;
            card2Button.Visibility = Visibility.Visible;
            card3Button.Visibility = Visibility.Visible;
            CardUser.Visibility = Visibility.Visible;
            CardAI.Visibility = Visibility.Visible;
            NewGameButton.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Visible;
            EndGame.Visibility = Visibility.Collapsed;
            StartButton.Visibility = Visibility.Collapsed;
            User.Visibility = Visibility.Visible;
            AI.Visibility = Visibility.Visible;
            Scores.Visibility = Visibility.Visible;
            GameRules.Visibility = Visibility.Collapsed;
            RandomCards();
            CardUser.DisplayFace(14);
            CardAI.DisplayFace(14);
            //Enable the game buttons 
            DisableButtons(true);
        }
        //Button for ending game. 
        private void EndGame_Click(object sender, RoutedEventArgs e)
        {
            GameRule.Visibility = Visibility.Visible;
            Card1.Visibility = Visibility.Collapsed;
            Card2.Visibility = Visibility.Collapsed;
            Card3.Visibility = Visibility.Collapsed;
            card1Button.Visibility = Visibility.Collapsed;
            card2Button.Visibility = Visibility.Collapsed;
            card3Button.Visibility = Visibility.Collapsed;
            CardUser.Visibility = Visibility.Collapsed;
            CardAI.Visibility = Visibility.Collapsed;
            NewGameButton.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Collapsed;
            EndGame.Visibility = Visibility.Collapsed;
            StartButton.Visibility = Visibility.Visible;
            User.Visibility = Visibility.Collapsed;
            AI.Visibility = Visibility.Collapsed;
            Scores.Visibility = Visibility.Collapsed;
            GameRules.Visibility = Visibility.Visible;
            //RESET SCORES:
            GameRule.Text = "";
            TurnScoreUser.Text = "Turn Score User: ";
            TurnScoreAI.Text = "Turn Score AI: ";
            OverallScoreAI.Text = "Turn Score User: ";
            OverallScoreUser.Text = "Overall Score User: ";
            WinText.Text = "";
            ShuffleCount = 0;
            Score = 0;
            AIScore = 0;
            
        }
        //Button for New Game.
        private void NewGameButton_Click(object sender, RoutedEventArgs e)
        {
            StartButton.Visibility = Visibility.Collapsed;
            EndGame.Visibility = Visibility.Collapsed;
            ShuffleButton.Visibility = Visibility.Visible;
            NewGameButton.Visibility = Visibility.Collapsed;
            TurnScoreUser.Text = "Turn Score User: ";
            TurnScoreAI.Text = "Turn Score AI: ";
            OverallScoreAI.Text = "Turn Score User: ";
            OverallScoreUser.Text = "Overall Score User: ";
            ShuffleCount = 0;
            WinText.Text = "";
            CardUser.DisplayFace(14);
            CardAI.DisplayFace(14);
            RandomCards();
            DisableButtons(true);
            GameRule.Text = "";
        }
        /****************************************************************************************
        * Method: Pick Card Buttons
        * Programmer(s):  Upma Sharma, Duncan Levings
        * Date: August 13, 2018
        * Description: Buttons 1-3, chose by user. Upon selection, the card buttons are disabled,
        * card back shown, AI selects card, game rules applied.
        * *************************************************************************************/
        //If Card 1 button selected. 
        private void card1Button_Click(object sender, RoutedEventArgs e)
        {
            DisableButtons(false);
            AISelectCard();
            CardUser.DisplayFace(Card[0]);
            BackCards();
            int PlayerIndex = Card[0];
            ApplyGameRules(PlayerIndex);
            

        }
        //If Card 2 button selected. 
        private void card2Button_Click(object sender, RoutedEventArgs e)
        
        {
            DisableButtons(false);
            AISelectCard();
            CardUser.DisplayFace(Card[1]);
            BackCards();
            int PlayerIndex = Card[1];
            ApplyGameRules(PlayerIndex);

        }
        //If Card 3 button selected. 
        private void card3Button_Click(object sender, RoutedEventArgs e)
        {
            DisableButtons(false);
            AISelectCard();
            CardUser.DisplayFace(Card[2]);
            BackCards();
            int PlayerIndex = Card[2];
            ApplyGameRules(PlayerIndex);
        }

        /****************************************************************************************
        * Method: Random Card AI
        * Programmer(s):  Upma Sharma
        * Date: August 13, 2018
        * Description: Method to generate a random card for AI and display card face.
        * *************************************************************************************/
        private void AISelectCard()
        {
            int CardValueAI = RandomGenerator.Next(1, 13);
            CardAI.DisplayFace(CardValueAI);

        }

        //Disable/Enable Card buttons function. 
        /****************************************************************************************
        * Method: Disable Enable Card Buttons Logic
        * Programmer(s):  Upma Sharma Duncan Levings
        * Date: August 15, 2018
        * Description: Function enables or disables buttons according to game rule needs. Once
        * card is selected by player.
        * *************************************************************************************/
        private void DisableButtons(bool set)
        {
            card1Button.IsEnabled = set;
            card2Button.IsEnabled = set;
            card3Button.IsEnabled = set;
        }

        /****************************************************************************************
        * Method: Game Rules Button
        * Programmer(s):  Upma Sharma, Aditya Chattopadhyay
        * Date: August 15, 2018
        * Description: Game Rules Button along with output text. Visible with start button and for
        * new game instances
        * *************************************************************************************/
        private void GameRules_Click_1(object sender, RoutedEventArgs e)
        {
            GameRule.Text = "\t\t\t Press the Start Button. \n " +
                "You will be presented with three randomly chosen cards of a set of 13." +
                " Choose one of the three randomly chosen cards from the deck." +
                " The lowest value card is 1 and highest is the King valued at 13." +
                " If you're unhappy with your card. You can shuffle the deck.\n " +
                " You can only shuffle twice, so do so wisely.\n " +
                " Once you select the card, the AI will select one randomly \n" +
                " Points will be awarded to the player with the higher valued card. ((card1 + card2) * 100)." +
                " You may choose to end the game or start a New Game at any time. \n " +
                "\t\t\t Good Luck!";
        }
    }
}

