﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace UpmaCardGameSimple
{
    public sealed partial class CardImage : UserControl
    {
      

        private const int NumFaces = 14;
        public Image[] Faces = new Image[NumFaces];

        public CardImage()
        {
            this.InitializeComponent();
            CreateFaceArray();
        }

        private void CreateFaceArray()
        {
            Faces[0] = Card1;
            Faces[1] = Card2;
            Faces[2] = Card3;
            Faces[3] = Card4;
            Faces[4] = Card5;
            Faces[5] = Card6;
            Faces[6] = Card7;
            Faces[7] = Card8;
            Faces[8] = Card9;
            Faces[9] = Card10;
            Faces[10] = Card11;
            Faces[11] = Card12;
            Faces[12] = Card13;
            Faces[13] = CardBack;
        }

        public void DisplayFace(int FaceID)
        {
            FaceID = FaceID - 1;

            for (int i = 0; i < NumFaces; i++)
            {
                if (i == FaceID)
                {
                    Faces[i].Visibility = Visibility.Visible;
                }
                else
                {
                    Faces[i].Visibility = Visibility.Collapsed;
                }
            }
        }
    }
}
